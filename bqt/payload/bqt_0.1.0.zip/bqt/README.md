# bqt.py

This is a blender startup script that allows for creating PySide2 based QtWidgets from within blender.

# Supported Platforms

Currently this script only works under Windows, because I don't have access to other platforms.
Pull requests very welcome.
